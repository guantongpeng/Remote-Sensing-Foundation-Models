import json
from mmcv.runner import OPTIMIZER_BUILDERS, DefaultOptimizerConstructor
from mmcv.runner import get_dist_info


def get_num_layer_for_swin(var_name, num_max_layer, depths, layer_sep=None):
    if var_name in ("backbone.absolute_pos_embed"):
        return 0
    elif var_name.startswith("backbone.patch_embed"):
        return 0
    elif var_name.startswith("backbone.stages") and 'blocks' in var_name:
        stage_id = int(var_name.split('.')[2])
        block_id = int(var_name.split('.')[4])
        if stage_id > 0:
            layer_id = sum(depths[:stage_id]) + block_id
        else:
            layer_id = block_id
        return layer_id + 1
    elif var_name.startswith("backbone.stages") and 'downsample' in var_name:
        stage_id = int(var_name.split('.')[2])
        layer_id = sum(depths[:(stage_id + 1)])
        return layer_id + 1
    else:
        return num_max_layer - 1


def get_num_layer_for_swin_v2(var_name, num_max_layer, depths, layer_sep=None):
    if var_name in ("backbone.absolute_pos_embed"):
        return 0
    elif var_name.startswith("backbone.patch_embed"):
        return 0
    elif var_name.startswith("backbone.stages") and 'blocks' in var_name:
        stage_id = int(var_name.split('.')[2])
        block_id = int(var_name.split('.')[4])
        if stage_id > 0:
            layer_id = sum(depths[:stage_id]) + block_id
        else:
            layer_id = block_id
        return layer_id + 1
    elif var_name.startswith("backbone.stages") and 'downsample' in var_name:
        stage_id = int(var_name.split('.')[2])
        layer_id = sum(depths[:(stage_id)])
        return layer_id + 1
    else:
        return num_max_layer - 1


@OPTIMIZER_BUILDERS.register_module()
class LayerDecayOptimizerConstructorSwin(DefaultOptimizerConstructor):

    def add_params(self, params, module, prefix='', is_dcn_module=None):
        """Add all parameters of module to the params list.
        The parameters of the given module will be added to the list of param
        groups, with specific rules defined by paramwise_cfg.
        Args:
            params (list[dict]): A list of param groups, it will be modified
                in place.
            module (nn.Module): The module to be added.
            prefix (str): The prefix of the module
            is_dcn_module (int|float|None): If the current module is a
                submodule of DCN, `is_dcn_module` will be passed to
                control conv_offset layer's learning rate. Defaults to None.
        """
        # get param-wise options

        parameter_groups = {}
        print(self.paramwise_cfg)
        num_layers = self.paramwise_cfg.get('num_layers') + 2
        depths = self.paramwise_cfg.get('depths')
        layer_sep = self.paramwise_cfg.get('layer_sep', None)
        layer_decay_rate = self.paramwise_cfg.get('layer_decay_rate')
        print("Build LayerDecayOptimizerConstructor %f - %d" %
              (layer_decay_rate, num_layers))
        weight_decay = self.base_wd

        custom_keys = self.paramwise_cfg.get('custom_keys', {})
        # first sort with alphabet order and then sort with reversed len of str
        sorted_keys = sorted(custom_keys.keys())

        for name, param in module.named_parameters():

            if not param.requires_grad:
                continue  # frozen weights

            if len(param.shape) == 1 or name.endswith(".bias") or (
                    'pos_embed' in name) or ('cls_token' in name) or (
                        'rel_pos_' in name) or ('relative_position_bias_table'
                                                in name):
                group_name = "no_decay"
                this_weight_decay = 0.
            else:
                group_name = "decay"
                this_weight_decay = weight_decay

            layer_id = get_num_layer_for_swin(name, num_layers, depths,
                                              layer_sep)
            group_name = "layer_%d_%s" % (layer_id, group_name)

            # if the parameter match one of the custom keys, ignore other rules
            this_lr_multi = 1.
            for key in sorted_keys:
                if key in f'{name}':
                    lr_mult = custom_keys[key].get('lr_mult', 1.)
                    this_lr_multi = lr_mult
                    group_name = "%s_%s" % (group_name, key)
                    break

            if group_name not in parameter_groups:
                scale = layer_decay_rate**(num_layers - layer_id - 1)

                parameter_groups[group_name] = {
                    "weight_decay": this_weight_decay,
                    "params": [],
                    "param_names": [],
                    "lr_scale": scale,
                    "group_name": group_name,
                    "lr": scale * self.base_lr * this_lr_multi,
                }

            parameter_groups[group_name]["params"].append(param)
            parameter_groups[group_name]["param_names"].append(name)

        rank, _ = get_dist_info()
        if rank == 0:
            to_display = {}
            for key in parameter_groups:
                to_display[key] = {
                    "param_names": parameter_groups[key]["param_names"],
                    "lr_scale": parameter_groups[key]["lr_scale"],
                    "lr": parameter_groups[key]["lr"],
                    "weight_decay": parameter_groups[key]["weight_decay"],
                }
            print("Param groups = %s" % json.dumps(to_display, indent=2))

        params.extend(parameter_groups.values())


@OPTIMIZER_BUILDERS.register_module()
class SwinV2LayerDecayOptimizerConstructor(DefaultOptimizerConstructor):

    def add_params(self, params, module, prefix='', is_dcn_module=None):
        """Add all parameters of module to the params list.
        The parameters of the given module will be added to the list of param
        groups, with specific rules defined by paramwise_cfg.
        Args:
            params (list[dict]): A list of param groups, it will be modified
                in place.
            module (nn.Module): The module to be added.
            prefix (str): The prefix of the module
            is_dcn_module (int|float|None): If the current module is a
                submodule of DCN, `is_dcn_module` will be passed to
                control conv_offset layer's learning rate. Defaults to None.
        """
        # get param-wise options

        parameter_groups = {}
        print(self.paramwise_cfg)
        num_layers = self.paramwise_cfg.get('num_layers') + 2
        depths = self.paramwise_cfg.get('depths')
        layer_sep = self.paramwise_cfg.get('layer_sep', None)
        layer_decay_rate = self.paramwise_cfg.get('layer_decay_rate')
        print("Build SwinV2LayerDecayOptimizerConstructor %f - %d" %
              (layer_decay_rate, num_layers))
        weight_decay = self.base_wd

        custom_keys = self.paramwise_cfg.get('custom_keys', {})
        # first sort with alphabet order and then sort with reversed len of str
        sorted_keys = sorted(custom_keys.keys())

        for name, param in module.named_parameters():

            if not param.requires_grad:
                continue  # frozen weights

            if len(param.shape) == 1 or name.endswith(".bias") or (
                    'pos_embed' in name) or ('cls_token' in name):
                group_name = "no_decay"
                this_weight_decay = 0.
            else:
                group_name = "decay"
                this_weight_decay = weight_decay

            layer_id = get_num_layer_for_swin_v2(name, num_layers, depths,
                                                 layer_sep)
            group_name = "layer_%d_%s" % (layer_id, group_name)

            # if the parameter match one of the custom keys, ignore other rules
            this_lr_multi = 1.
            for key in sorted_keys:
                if key in f'{name}':
                    lr_mult = custom_keys[key].get('lr_mult', 1.)
                    this_lr_multi = lr_mult
                    group_name = "%s_%s" % (group_name, key)
                    break

            if group_name not in parameter_groups:
                scale = layer_decay_rate**(num_layers - layer_id - 1)

                parameter_groups[group_name] = {
                    "weight_decay": this_weight_decay,
                    "params": [],
                    "param_names": [],
                    "lr_scale": scale,
                    "group_name": group_name,
                    "lr": scale * self.base_lr * this_lr_multi,
                }

            parameter_groups[group_name]["params"].append(param)
            parameter_groups[group_name]["param_names"].append(name)

        rank, _ = get_dist_info()
        if rank == 0:
            to_display = {}
            for key in parameter_groups:
                to_display[key] = {
                    "param_names": parameter_groups[key]["param_names"],
                    "lr_scale": parameter_groups[key]["lr_scale"],
                    "lr": parameter_groups[key]["lr"],
                    "weight_decay": parameter_groups[key]["weight_decay"],
                }
            print("Param groups = %s" % json.dumps(to_display, indent=2))

        params.extend(parameter_groups.values())
